public class RectangleService {
    public static double getPerimeter(double w, double h){
        return w + h + w + h;
    }
    public static double getArea(double w, double h){
        return w * h;
    }
}
