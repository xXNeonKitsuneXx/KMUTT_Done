public interface GeometricObjectInterface {
    public static final String color = "white";
    public double getArea();
    public double getPerimeter();
}